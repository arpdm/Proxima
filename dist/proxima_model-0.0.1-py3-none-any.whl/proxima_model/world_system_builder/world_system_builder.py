"""
Worlds System Builder
==============================

Description:
    This is the main entry point for running the Proxima - World System Beta Phase 1

Author:
    Arpi Derm <arpiderm@gmail.com>

Created:
    July 5, 2024

Usage:
    To run the simulation, execute this script using poetry
        poetry run lunar-power-grid

License:
    MIT License

Functions:
    - main: The main function to set up and run the lunar power grid simulation.

"""

from proxima_model.tools import ts_plot as pl

import pandas as pd
import numpy as np
import networkx as nx

from mesa import Model
from mesa.datacollection import DataCollector


class WorldSystem(Model):
    def __init__(self, config, seed=None):
        super().__init__(seed=seed)
        self.config = config
        self.daylight = self.is_day(self.steps)
        self.initialize_microgrid()

        self.datacollector = DataCollector(
            model_reporters={
                "Step": lambda m: int(m.steps),
                "Daylight": lambda m: m.daylight,
            },
            agent_reporters={
                "P_Need (kWh)": "p_need",
                "Total Power Supplied (kWh)": "total_p_supply",
                "Total Charge Level (kWh)": "total_charge_level",
                "Total SoC (%)": "total_state_of_charge",
                "Total Charge Capacity (kWh)": "total_charge_capacity",
                "Excess Energy (kW)": "excess_energy",
                "Battery Charge/Discharge (kwh)": "total_p_bat",
            },
        )

        self.running = True

    def is_day(self, t):
        lunar_day_hours = CONFIG.LUNAR_DAY_HOURS
        lunar_night_hours = CONFIG.LUNAR_NIGHT_HOURS  # default 14 Earth days
        cycle_length = lunar_day_hours + lunar_night_hours
        phase = t % cycle_length
        return 1 if phase < lunar_day_hours else 0

    def initialize_microgrid(self):
        self.microgrid = MicrogridManager(self, config=self.config)

    def step(self):
        self.daylight = self.is_day(self.steps)
        self.microgrid.step()
        self.microgrid.advance()
        self.datacollector.collect(self)
        self.running = self.steps < self.config["sim_time"]
