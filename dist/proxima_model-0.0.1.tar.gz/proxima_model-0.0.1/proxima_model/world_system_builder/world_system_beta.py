"""
lunar_power_grid_simulation.py
==============================

Description:
    This is the main entry point for running the Proxima - World System Beta Phase 1

Author:
    Arpi Derm <arpiderm@gmail.com>

Created:
    July 5, 2024

Usage:
    To run the simulation, execute this script using poetry
        poetry run lunar-power-grid

License:
    MIT License

Functions:
    - main: The main function to set up and run the lunar power grid simulation.

"""

from proxima_model.tools import ts_plot as pl
from pathlib import Path
from types import SimpleNamespace
from datetime import datetime, timezone

import json
import yaml
import pandas as pd
import numpy as np
import networkx as nx

from mesa import Agent, Model
from mesa.datacollection import DataCollector
from mesa.space import NetworkGrid

# World System Beta Model
class WorldSystemBetaModel(Model):

    def __init__(self, seed=None):
        super().__init__(seed=seed)

        # Dynamic states
        self.daylight = is_day(self.steps)

        # Create Zone Energy Infrastructure
        self.initialize_microgrid()

        # DataCollector
        self.datacollector = DataCollector(
            model_reporters={
                "Step": lambda m: int(m.steps),
                "Daylight": lambda m: m.daylight,
            },
            agent_reporters={
                "P_Need (kWh)": "p_need",
                "Total Power Supplied (kWh)": "total_p_supply",
                "Total Charge Level (kWh)": "total_charge_level",
                "Total SoC (%)": "total_state_of_charge",
                "Total Charge Capacity (kWh)": "total_charge_capacity",
                "Excess Energy (kW)": "excess_energy",
                "Battery Charge/Discharge (kwh)": "total_p_bat",
            },
        )

        # Set Model Running and start data collector
        self.running = True

    def step(self):
        # Caclulate day time
        self.daylight = is_day(self.steps)

        # Run the microgrid
        self.microgrid.do("step")
        self.microgrid.do("advance")

        # Collect data at every simulation step
        self.datacollector.collect(self)

        self.running = self.steps < CONFIG.SIM_TIME

    def initialize_microgrid(self):
        self.microgrid = MicrogridManager.create_agents(self, 1)


def main():

    # Start Simulation
    start_time = datetime.now(timezone.utc).timestamp()
    ws_1 = WorldSystemBetaModel()

    # Run Simulation
    for _ in range(CONFIG.SIM_TIME):
        ws_1.step()

    # Save Simulation Results
    results = ws_1.datacollector.get_model_vars_dataframe()
    agent_df = ws_1.datacollector.get_agent_vars_dataframe()
    agent_df.to_csv(f"log_files/WS_Beta_Agent_{start_time}.csv")
    results.to_csv(f"log_files/WS_Beta_Model_{start_time}.csv")


if __name__ == "__main__":
    main()
